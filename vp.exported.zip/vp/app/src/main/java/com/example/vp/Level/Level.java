package com.example.vp.Level;

import androidx.fragment.app.Fragment;

import com.example.vp.Water.Water;

import java.util.List;

public class Level extends Fragment {

    private String nameLevel;
    private List<Water> waters;


    public Level(String nameLevel, List<Water> waters) {
        this.nameLevel = nameLevel;
        this.waters = waters;

    }

    public String getNameLevel() {
        return nameLevel;
    }

    public void setNameLevel(String nameLevel) {
        this.nameLevel = nameLevel;
    }

    public List<Water> getWaters() {
        return waters;
    }

    public void setWaters(List<Water> waters) {
        this.waters = waters;
    }

}
package com.example.vp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.vp.Level.Level;
import com.example.vp.Level.LevelAdapter;
import com.example.vp.Water.Water;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends PagerAdapter {
    private Context mContext;

    public CustomAdapter(Context mContext) {
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        switch (position) {
            case 0:

            case 1:
                return
            case 2:
                return
            default:
                return null;
        };
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public boolean isViewFromObject( View view, Object object) {
        return view == object;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return ;
    }
}
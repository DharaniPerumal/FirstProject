package com.example.vp.Water;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vp.R;

import java.util.List;

public class WaterAdapter extends RecyclerView.Adapter<WaterAdapter.WaterViewAdapter>{
    private Context mContext;
    private List<Water> mWaters;

    public WaterAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public WaterAdapter() {

    }

    public void setData (List<Water> list){
        this.mWaters =  list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public WaterViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.water,parent,false);
        return new WaterViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WaterViewAdapter holder, int position) {
        Water water = mWaters.get(position);
        if(water == null){
            return;
        }
        holder.tvTitle.setText(water.getTitle());
        holder.tvPercentage.setText(water.getPercentage());
        holder.tvLength.setText(water.getLength());
    }

    @Override
    public int getItemCount() {
        if(mWaters != null){
            return mWaters.size();
        }
        return 0;
    }

    public class WaterViewAdapter extends RecyclerView.ViewHolder{
        private TextView tvTitle;
        private TextView tvPercentage;
        private TextView tvLength;


        public WaterViewAdapter(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tv_11);
            tvLength = itemView.findViewById(R.id.length_1);
            tvPercentage = itemView.findViewById(R.id.tv_per);

        }
    }
}

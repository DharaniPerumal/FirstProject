package com.example.vp.Water;

public class Water {

    private String title,percentage,length;

    public Water(String title, String percentage, String length) {
        this.title = title;
        this.percentage = percentage;
        this.length = length;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }

}

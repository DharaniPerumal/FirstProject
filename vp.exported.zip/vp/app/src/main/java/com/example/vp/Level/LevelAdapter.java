package com.example.vp.Level;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;

import com.example.vp.R;
import com.example.vp.Water.WaterAdapter;

import java.util.List;

public class LevelAdapter extends  RecyclerView.Adapter<LevelAdapter.LevelVieWHolder>{

    private Context mContext;
    private List<Level> mListLevel;

    public LevelAdapter(Context mContext) {
        this.mContext = mContext;
    }
    public void setData(List<Level>list){
        this.mListLevel =  list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public LevelVieWHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.level,parent,false);
        return new LevelVieWHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LevelVieWHolder holder, int position) {
        Level level = mListLevel.get(position);
        if (level == null){
            return;
        }

        holder.tvNameLevel.setText(level.getNameLevel());

        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext,3);
        holder.rcvWater.setLayoutManager(gridLayoutManager);

        WaterAdapter waterAdapter = new WaterAdapter();
        waterAdapter.setData(level.getWaters());
        holder.rcvWater.setAdapter(waterAdapter);
    }

    @Override
    public int getItemCount() {
        if(mListLevel != null){
            return mListLevel.size();
        }
        return 0;
    }

    public class LevelVieWHolder extends RecyclerView.ViewHolder{

        private TextView tvNameLevel;
        private RecyclerView rcvWater;

        public LevelVieWHolder(@NonNull View itemView) {
            super(itemView);

            tvNameLevel = itemView.findViewById(R.id.tv_namelevel);
            rcvWater= itemView.findViewById(R.id.rcv_water);
        }
    }
}